from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from django.contrib.auth.hashers import make_password,check_password
from django.views import View 


# Create your views here.
def index(request):
    products = None
    category = Category.get_all_category()
    categoryid = request.GET.get('category')
    if categoryid:
        products = Product.get_all_product_by_cegegory_id(categoryid)
    else:
        products = Product.get_all_products()
    data = {'products':products,'category':category}
    return render(request,'index.html',data)

# function foe Signup
def Signup(request):
    if request.method =='GET':
        return render(request,'Signup.html')
        print("abhishek")
    else:
        return registerUser(request)    


# function for validation 
def validateCustomer(customer):
    error_message = None
    if not customer.first_name:
        error_message = "First name is requred"
    elif len(customer.first_name)<4:
        error_message = "first name must we more then four Character"
    elif not customer.lasr_name:
        error_message = "last name is requred"
    elif len(customer.lasr_name)<4:
        error_message = "length of last name is must be more then four character"
    elif not customer.phone:
            error_message = "phone number is requred"
    elif not customer.email:
        error_message = "Email is requred"
    elif not customer.password:
        error_message = "password is requred"
    elif customer.isExist():
        error_message = "Email is allradey exist"

    return error_message

# function for register user in to data base 
def registerUser(request):
    postdata = request.POST
    first_name = postdata.get('name')
    last_name = postdata.get('lastname')
    phone = postdata.get('mobilenumber')
    email = postdata.get('email')
    password = postdata.get('password')
        # print(first_name,last_name,number,email,password)
    
        # validation 
    values={
        'first_name':first_name,
        'lasr_name':last_name,
        'phone':phone,
        'email':email
        }
    error_message = None
    customer = Customer(first_name=first_name,lasr_name=last_name,phone=phone,email=email,password=password)
        
    error_message = validateCustomer(customer)
        # save data in to database if cant find any error messagwe
    if not error_message:
        customer.password=make_password(customer.password)
        customer.register()
        return redirect('homepage')
    else:
        data = {
            'error':error_message,
            'values':values
        }
        return render(request,'Signup.html',data)


# function foe Signup
def Signup(request):
    if request.method=='GET':
        return render(request,'Signup.html')
    else:
        return registerUser(request)


# class  for login handle bith methide grt and post 
class login(View):
    def get(self , request):
        return render(request,'login.html')

    def post(self ,request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            flag = check_password(password ,customer.password)
            if flag:
                return redirect('homepage')
            else:
                error_message = "Email or Password is Invalid"
        else:
            error_message = "Email or Password is Invalid"       
        return render(request,'login.html',{'error':error_message})

        

   
    