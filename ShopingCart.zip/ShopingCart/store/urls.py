from django.conf.urls import url
from store import views
from .views import login

urlpatterns = [
    url('',views.index, name='homepage'),
    url('Signup',views.Signup),
    url('login',login.as_view())

]