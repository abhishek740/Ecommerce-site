from django.contrib import admin
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
# Register your models here.

class AdminProduct(admin.ModelAdmin):
    List_Display=['name','price','cetegory','description']

class AdminCetegory(admin.ModelAdmin):
    List_Display=['name']

admin.site.register(Product,AdminProduct)
admin.site.register(Category,AdminCetegory)
admin.site.register(Customer)